/* ============================================================
   EduVerse Student Enrollment System – site.js
   ============================================================ */

'use strict';

/* ────────────────────────────────────────────────
   Credit Card Input Formatting
   ──────────────────────────────────────────────── */
function initCardFormatting() {
    const cardNum = document.getElementById('CardNumber');
    if (cardNum) {
        cardNum.addEventListener('input', function () {
            let v = this.value.replace(/\D/g, '').substring(0, 16);
            this.value = v.replace(/(.{4})/g, '$1 ').trim();
            updateCardPreview();
        });
    }

    const expMonth = document.getElementById('ExpiryMonth');
    const expYear  = document.getElementById('ExpiryYear');
    const cvv      = document.getElementById('CVV');
    const name     = document.getElementById('CardholderName');

    [expMonth, expYear, cvv, name].forEach(el => {
        if (el) el.addEventListener('input', updateCardPreview);
    });
}

function updateCardPreview() {
    const num   = document.getElementById('CardNumber')?.value || '';
    const month = document.getElementById('ExpiryMonth')?.value || 'MM';
    const year  = document.getElementById('ExpiryYear')?.value || 'YY';
    const cname = document.getElementById('CardholderName')?.value || 'YOUR NAME';

    const previewNum  = document.getElementById('previewNumber');
    const previewExp  = document.getElementById('previewExpiry');
    const previewName = document.getElementById('previewName');

    if (previewNum)  previewNum.textContent  = num || '•••• •••• •••• ••••';
    if (previewExp)  previewExp.textContent  = `${month}/${year}`;
    if (previewName) previewName.textContent = cname.toUpperCase();
}

/* ────────────────────────────────────────────────
   Password Strength Indicator
   ──────────────────────────────────────────────── */
function initPasswordStrength() {
    const pwdInput = document.getElementById('Password') || document.getElementById('NewPassword');
    const indicator = document.getElementById('passwordStrength');
    if (!pwdInput || !indicator) return;

    pwdInput.addEventListener('input', function () {
        const val = this.value;
        let strength = 0;
        if (val.length >= 8)  strength++;
        if (/[A-Z]/.test(val)) strength++;
        if (/[0-9]/.test(val)) strength++;
        if (/[^A-Za-z0-9]/.test(val)) strength++;

        const labels = ['', 'Weak', 'Fair', 'Good', 'Strong'];
        const colors = ['', '#ef4444', '#f59e0b', '#3b82f6', '#10b981'];
        indicator.textContent  = val ? labels[strength] || 'Weak' : '';
        indicator.style.color  = colors[strength] || '';
    });
}

/* ────────────────────────────────────────────────
   Conflict Check on Enrollment
   ──────────────────────────────────────────────── */
function checkConflict(courseId, btn) {
    const badge = btn.parentElement.querySelector('.conflict-badge');
    if (badge) badge.remove();

    fetch(`/Enrollment/CheckConflict?courseId=${courseId}`)
        .then(r => r.json())
        .then(data => {
            if (data.hasConflict) {
                const b = document.createElement('div');
                b.className = 'alert alert-warning p-2 mt-2 mb-0 small conflict-badge';
                b.innerHTML = `<i class="bi bi-exclamation-triangle me-1"></i>${data.message}`;
                btn.parentElement.appendChild(b);
                btn.disabled = true;
            }
        })
        .catch(() => {});
}

/* ────────────────────────────────────────────────
   Course Search / Filter
   ──────────────────────────────────────────────── */
function initCourseFilter() {
    const searchBox  = document.getElementById('courseSearch');
    const deptFilter = document.getElementById('deptFilter');
    const cards      = document.querySelectorAll('.course-card-wrapper');

    function filter() {
        const q    = (searchBox?.value || '').toLowerCase();
        const dept = (deptFilter?.value || '').toLowerCase();

        cards.forEach(card => {
            const text = card.textContent.toLowerCase();
            const show = (!q || text.includes(q)) && (!dept || text.includes(dept));
            card.style.display = show ? '' : 'none';
        });

        const visible = [...cards].filter(c => c.style.display !== 'none').length;
        const empty   = document.getElementById('noResults');
        if (empty) empty.style.display = visible === 0 ? 'block' : 'none';
    }

    searchBox?.addEventListener('input', filter);
    deptFilter?.addEventListener('change', filter);
}

/* ────────────────────────────────────────────────
   Confirm Dialogs
   ──────────────────────────────────────────────── */
function confirmDrop(form, courseName) {
    if (confirm(`Are you sure you want to drop "${courseName}"? This action will be recorded.`)) {
        form.submit();
    }
}

/* ────────────────────────────────────────────────
   Payment simulation loading
   ──────────────────────────────────────────────── */
function initPaymentForm() {
    const form = document.getElementById('paymentForm');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        const btn = document.getElementById('payBtn');
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Processing...';
        }
    });
}

/* ────────────────────────────────────────────────
   Auto-format phone numbers
   ──────────────────────────────────────────────── */
function initPhoneFormat() {
    document.querySelectorAll('input[type="tel"]').forEach(el => {
        el.addEventListener('input', function () {
            this.value = this.value.replace(/[^\d+\-\s()]/g, '');
        });
    });
}

/* ────────────────────────────────────────────────
   Animate stat counters on dashboard
   ──────────────────────────────────────────────── */
function animateCounters() {
    document.querySelectorAll('[data-count]').forEach(el => {
        const target = parseInt(el.dataset.count, 10);
        let current = 0;
        const step = Math.ceil(target / 40);
        const timer = setInterval(() => {
            current = Math.min(current + step, target);
            el.textContent = current.toLocaleString();
            if (current >= target) clearInterval(timer);
        }, 20);
    });
}

/* ────────────────────────────────────────────────
   Toast auto-close
   ──────────────────────────────────────────────── */
function initToasts() {
    document.querySelectorAll('.toast-auto').forEach(el => {
        setTimeout(() => {
            el.classList.remove('show');
        }, 4000);
    });
}

/* ────────────────────────────────────────────────
   Client-side form validation helpers
   ──────────────────────────────────────────────── */
function validateEnrollmentForm() {
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function (e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
}

/* ────────────────────────────────────────────────
   INIT
   ──────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function () {
    initCardFormatting();
    initPasswordStrength();
    initCourseFilter();
    initPaymentForm();
    initPhoneFormat();
    animateCounters();
    initToasts();
    validateEnrollmentForm();

    // Tooltips
    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => {
        new bootstrap.Tooltip(el);
    });
});
