# EduVerse Student Enrollment System
### ASP.NET Core 8 + SQL Server + Bootstrap 5

---

## 📁 PROJECT STRUCTURE

```
StudentEnrollmentSystem/
├── Controllers/
│   ├── AccountController.cs      # Login, Register, Profile, Password, BankDetails
│   ├── HomeController.cs         # Landing page, Dashboard
│   ├── EnrollmentController.cs   # Browse & enroll courses
│   └── OtherControllers.cs       # AddDrop, Enquiry, Statement, Payment, Admin
├── Data/
│   └── DatabaseContext.cs        # ADO.NET connection helper
├── Database/
│   └── schema.sql                # Full SQL schema + seed data
├── Models/
│   └── Models.cs                 # All entity and view models
├── Services/
│   ├── StudentService.cs         # Auth, profile, bank details
│   ├── CourseEnrollmentService.cs# Courses, enrollment, add/drop
│   └── OtherServices.cs          # Payment, enquiry, statement
├── Views/
│   ├── Shared/_Layout.cshtml     # Sidebar layout
│   ├── Account/                  # Login, Register, Profile, Password, BankDetails
│   ├── AddDrop/                  # Index, History
│   ├── Admin/                    # Index, Students, Courses, Enquiries
│   ├── Enquiry/                  # Contact, Timetable, Feedback, MyEnquiries
│   ├── Enrollment/               # Index (browse), MyCourses
│   ├── Home/                     # Index (landing), Dashboard
│   ├── Payment/                  # Pay, Index (history), Receipt
│   └── Statement/                # Index, RegistrationSummary, Timetable, Invoice
├── wwwroot/
│   ├── css/site.css              # Full custom stylesheet
│   └── js/site.js                # Client-side interactions
├── appsettings.json              # Connection string & config
├── Program.cs                    # App startup & DI
└── StudentEnrollmentSystem.csproj
```

---

## ✅ PREREQUISITES

| Tool | Version | Download |
|------|---------|----------|
| Visual Studio 2022 | 17.8+ | https://visualstudio.microsoft.com |
| .NET SDK | 8.0+ | https://dotnet.microsoft.com/download |
| SQL Server | 2019/2022 or Express | https://www.microsoft.com/sql-server |
| SQL Server Management Studio | Any | https://aka.ms/ssms |

---

## ▶️ HOW TO RUN (Step-by-Step)

### Step 1 — Clone / Extract the Project
```
cd C:\Projects
# Extract the ZIP here so you have:
# C:\Projects\StudentEnrollmentSystem\
```

### Step 2 — Set Up the Database
1. Open **SQL Server Management Studio (SSMS)**
2. Connect to your SQL Server instance (e.g. `localhost` or `.\SQLEXPRESS`)
3. Open a new query window
4. Open and run `Database/schema.sql`
   - This creates the `StudentEnrollmentDB` database
   - Creates all tables with PKs and FKs
   - Inserts seed data (students, courses, timetables, sample payments)

### Step 3 — Configure Connection String
Open `appsettings.json` and update if needed:

```json
"ConnectionStrings": {
  "DefaultConnection": "Server=localhost;Database=StudentEnrollmentDB;Trusted_Connection=True;TrustServerCertificate=True;"
}
```

- For SQL Express: `Server=.\SQLEXPRESS;...`
- For SQL Auth: `Server=localhost;Database=StudentEnrollmentDB;User Id=sa;Password=YourPass;TrustServerCertificate=True;`

### Step 4 — Restore NuGet Packages
```bash
cd StudentEnrollmentSystem
dotnet restore
```
Or in Visual Studio: Right-click solution → Restore NuGet Packages

### Step 5 — Build & Run
```bash
dotnet run
```
Or press **F5** in Visual Studio.

The app starts at: **https://localhost:5001** (or http://localhost:5000)

---

## 🔐 LOGIN CREDENTIALS

| Role    | Email                          | Password     |
|---------|-------------------------------|--------------|
| Admin   | admin@university.edu           | Admin@123    |
| Student | ahmad.razali@student.edu       | Student@123  |
| Student | siti.nurhaliza@student.edu     | Student@123  |
| Student | rajesh.kumar@student.edu       | Student@123  |

---

## 💳 PAYMENT TESTING (Dummy Gateway)

Use any of these test card numbers:
- **Visa:** 4111 1111 1111 1111
- **Mastercard:** 5500 0000 0000 0004
- Any future expiry date and any 3-digit CVV

---

## 🗄️ DATABASE TABLES

| Table              | Description                              |
|--------------------|------------------------------------------|
| Roles              | Admin / Student roles                    |
| Students           | All users (students + admin)             |
| Courses            | Available courses                        |
| CourseTimetable    | Day/time/room per course                 |
| Enrollments        | Student-course enrollments               |
| AddDropHistory     | Add/drop transaction log                 |
| Payments           | Payment transactions                     |
| Invoices           | Fee invoices                             |
| InvoiceItems       | Line items per invoice                   |
| Enquiries          | Contact form submissions                 |
| Feedback           | Student evaluation of teaching           |
| BankDetails        | Student bank account info                |
| Announcements      | Admin announcements on dashboard         |

---

## 🚀 FEATURES IMPLEMENTED

### ✅ Online Enrollment
- Browse all available courses with search & department filter
- View capacity bars, timetable slots, fees
- Real-time schedule conflict detection before enrolling
- One-click enrollment

### ✅ Add / Drop
- Drop enrolled courses with reason selection
- Add available courses
- Full Add/Drop history log stored in DB

### ✅ Enquiry
- Contact Us form (stored in DB, no email required)
- Timetable Matching — displays weekly grid + detects conflicts
- Student Evaluation of Teaching — star ratings per course

### ✅ Statement
- Student Statement — fee breakdown, invoices, payment history
- Registration Summary — printable official enrollment document
- Class Timetable — colour-coded weekly grid

### ✅ Payment
- Dummy card payment gateway (simulates 95% success)
- Payment history with status
- Printable receipt
- Invoice view with line items

### ✅ Account Management
- Change password with BCrypt validation
- Update profile (name, DOB, address, program, year)
- Update bank details

### ✅ Role-Based Access
- Admin role sees extra Admin menu
- Admin dashboard with student/course/enquiry counts
- Manage Students, Courses, and Enquiries pages
- Protected routes with `[Authorize(Roles = "Admin")]`

---

## 🛠️ TECHNICAL STACK

- **Backend:** ASP.NET Core 8 MVC (C#)
- **Database:** Microsoft SQL Server (ADO.NET — no EF)
- **Auth:** Cookie Authentication + BCrypt password hashing
- **Frontend:** Razor Views + Bootstrap 5.3 + Bootstrap Icons
- **Fonts:** Plus Jakarta Sans + Space Grotesk (Google Fonts)
- **Validation:** Server-side (Model validation) + Client-side (JS)

---

## 🔧 TROUBLESHOOTING

**Cannot connect to database**
- Make sure SQL Server service is running
- Check connection string Server name matches your instance
- Try `Server=.\SQLEXPRESS` for Express edition

**BCrypt errors / missing package**
```bash
dotnet add package BCrypt.Net-Next
dotnet add package Microsoft.Data.SqlClient
dotnet add package Microsoft.AspNetCore.Authentication.Cookies
```

**Port already in use**
- Change port in `Properties/launchSettings.json`

**Password hash mismatch for seed data**
- Re-run: `UPDATE Students SET PasswordHash = '<new_hash>' WHERE Email = '...'`
- Or register a new account and use those credentials

---

*EduVerse Student Enrollment System — Built with ASP.NET Core 8*
