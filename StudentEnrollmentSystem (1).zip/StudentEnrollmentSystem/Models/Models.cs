using System.ComponentModel.DataAnnotations;

namespace StudentEnrollmentSystem.Models
{
    // ─────────────────────────────────────────────────────────
    // Student / User Model
    // ─────────────────────────────────────────────────────────
    public class Student
    {
        public int StudentId { get; set; }
        public string StudentNumber { get; set; } = "";
        [Required, MaxLength(100)] public string FirstName { get; set; } = "";
        [Required, MaxLength(100)] public string LastName  { get; set; } = "";
        [Required, EmailAddress]   public string Email     { get; set; } = "";
        public string PasswordHash { get; set; } = "";
        public string? PhoneNumber { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? Address { get; set; }
        public string? Program { get; set; }
        public int YearLevel { get; set; } = 1;
        public int RoleId { get; set; } = 2;
        public string RoleName { get; set; } = "Student";
        public string? ProfilePicture { get; set; }
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        public string FullName => $"{FirstName} {LastName}";
        public bool IsAdmin   => RoleId == 1;
    }

    // ─────────────────────────────────────────────────────────
    // Course Model
    // ─────────────────────────────────────────────────────────
    public class Course
    {
        public int CourseId { get; set; }
        public string CourseCode { get; set; } = "";
        public string CourseName { get; set; } = "";
        public string? Description { get; set; }
        public int Credits { get; set; } = 3;
        public int MaxCapacity { get; set; } = 40;
        public int CurrentEnrolled { get; set; } = 0;
        public string? Instructor { get; set; }
        public string? Department { get; set; }
        public string? Semester { get; set; }
        public string? AcademicYear { get; set; }
        public decimal FeeAmount { get; set; }
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; }
        public List<CourseTimetable> Timetables { get; set; } = new();

        public int AvailableSeats => MaxCapacity - CurrentEnrolled;
        public bool IsFull => CurrentEnrolled >= MaxCapacity;
        public string StatusBadge => IsFull ? "Full" : AvailableSeats <= 5 ? "Almost Full" : "Available";
    }

    // ─────────────────────────────────────────────────────────
    // Timetable
    // ─────────────────────────────────────────────────────────
    public class CourseTimetable
    {
        public int TimetableId { get; set; }
        public int CourseId { get; set; }
        public string DayOfWeek { get; set; } = "";
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime   { get; set; }
        public string? Room     { get; set; }
        public string? Building { get; set; }

        public string TimeRange => $"{StartTime:hh\\:mm} - {EndTime:hh\\:mm}";
        public string CourseName  { get; set; } = "";
        public string CourseCode  { get; set; } = "";
    }

    // ─────────────────────────────────────────────────────────
    // Enrollment
    // ─────────────────────────────────────────────────────────
    public class Enrollment
    {
        public int EnrollmentId { get; set; }
        public int StudentId    { get; set; }
        public int CourseId     { get; set; }
        public DateTime EnrollmentDate { get; set; }
        public string Status    { get; set; } = "Active";
        public string? Grade    { get; set; }
        public string? Semester { get; set; }
        public string? AcademicYear { get; set; }

        // Joined
        public Course? Course { get; set; }
        public Student? Student { get; set; }
    }

    // ─────────────────────────────────────────────────────────
    // Add/Drop History
    // ─────────────────────────────────────────────────────────
    public class AddDropHistory
    {
        public int HistoryId   { get; set; }
        public int StudentId   { get; set; }
        public int CourseId    { get; set; }
        public string ActionType  { get; set; } = ""; // Add, Drop
        public DateTime ActionDate { get; set; }
        public string? Reason  { get; set; }
        public string? ProcessedBy { get; set; }
        public string? Semester   { get; set; }
        public string? AcademicYear { get; set; }

        // Joined
        public string CourseCode { get; set; } = "";
        public string CourseName { get; set; } = "";
    }

    // ─────────────────────────────────────────────────────────
    // Enquiry
    // ─────────────────────────────────────────────────────────
    public class Enquiry
    {
        public int EnquiryId  { get; set; }
        public int? StudentId { get; set; }
        [Required, MaxLength(200)] public string FullName { get; set; } = "";
        [Required, EmailAddress]   public string Email    { get; set; } = "";
        [Required, MaxLength(300)] public string Subject  { get; set; } = "";
        [Required, MaxLength(2000)]public string Message  { get; set; } = "";
        public string Status  { get; set; } = "Pending";
        public string? AdminReply { get; set; }
        public DateTime SubmittedAt { get; set; }
        public DateTime? RepliedAt  { get; set; }
    }

    // ─────────────────────────────────────────────────────────
    // Feedback (Student Evaluation of Teaching)
    // ─────────────────────────────────────────────────────────
    public class Feedback
    {
        public int FeedbackId { get; set; }
        public int StudentId  { get; set; }
        public int CourseId   { get; set; }
        [Range(1,5)] public int TeachingRating { get; set; }
        [Range(1,5)] public int ContentRating  { get; set; }
        [Range(1,5)] public int MaterialRating { get; set; }
        [Range(1,5)] public int OverallRating  { get; set; }
        public string? Comments { get; set; }
        public bool IsAnonymous { get; set; }
        public DateTime SubmittedAt { get; set; }
        public string? Semester    { get; set; }
        public string? AcademicYear { get; set; }

        // Joined
        public string CourseCode { get; set; } = "";
        public string CourseName { get; set; } = "";
        public string Instructor { get; set; } = "";
    }

    // ─────────────────────────────────────────────────────────
    // Payment
    // ─────────────────────────────────────────────────────────
    public class Payment
    {
        public int PaymentId   { get; set; }
        public int StudentId   { get; set; }
        public string PaymentReference { get; set; } = "";
        public decimal Amount  { get; set; }
        public string? PaymentMethod { get; set; }
        public string? CardLastFour  { get; set; }
        public DateTime PaymentDate  { get; set; }
        public string Status         { get; set; } = "Pending";
        public string? Description   { get; set; }
        public string? Semester      { get; set; }
        public string? AcademicYear  { get; set; }
    }

    // ─────────────────────────────────────────────────────────
    // Invoice
    // ─────────────────────────────────────────────────────────
    public class Invoice
    {
        public int InvoiceId { get; set; }
        public string InvoiceNumber { get; set; } = "";
        public int StudentId { get; set; }
        public int? PaymentId { get; set; }
        public decimal SubTotal    { get; set; }
        public decimal Discount    { get; set; }
        public decimal Tax         { get; set; }
        public decimal TotalAmount { get; set; }
        public string Status       { get; set; } = "Unpaid";
        public DateTime? DueDate   { get; set; }
        public DateTime IssuedDate { get; set; }
        public DateTime? PaidDate  { get; set; }
        public string? Notes       { get; set; }
        public string? Semester    { get; set; }
        public string? AcademicYear { get; set; }

        public List<InvoiceItem> Items { get; set; } = new();
        public Student? Student { get; set; }
    }

    public class InvoiceItem
    {
        public int ItemId      { get; set; }
        public int InvoiceId   { get; set; }
        public int? CourseId   { get; set; }
        public string Description { get; set; } = "";
        public int Quantity    { get; set; } = 1;
        public decimal UnitPrice  { get; set; }
        public decimal TotalPrice { get; set; }
    }

    // ─────────────────────────────────────────────────────────
    // Bank Details
    // ─────────────────────────────────────────────────────────
    public class BankDetails
    {
        public int BankDetailId { get; set; }
        public int StudentId    { get; set; }
        [MaxLength(200)] public string? BankName          { get; set; }
        [MaxLength(200)] public string? AccountHolderName { get; set; }
        [MaxLength(50)]  public string? AccountNumber     { get; set; }
        [MaxLength(50)]  public string? RoutingNumber     { get; set; }
        [MaxLength(20)]  public string? AccountType       { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    // ─────────────────────────────────────────────────────────
    // Announcement
    // ─────────────────────────────────────────────────────────
    public class Announcement
    {
        public int AnnouncementId { get; set; }
        public string Title   { get; set; } = "";
        public string Content { get; set; } = "";
        public int? CreatedBy  { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public bool IsActive { get; set; } = true;
    }

    // ─────────────────────────────────────────────────────────
    // View Models
    // ─────────────────────────────────────────────────────────
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        public string Email    { get; set; } = "";

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = "";

        public bool RememberMe { get; set; }
    }

    public class RegisterViewModel
    {
        [Required] public string FirstName { get; set; } = "";
        [Required] public string LastName  { get; set; } = "";
        [Required, EmailAddress] public string Email { get; set; } = "";
        [Required, MinLength(8, ErrorMessage = "Password must be at least 8 characters")]
        public string Password { get; set; } = "";
        [Compare("Password", ErrorMessage = "Passwords do not match")]
        public string ConfirmPassword { get; set; } = "";
        public string? PhoneNumber { get; set; }
        public string? Program     { get; set; }
    }

    public class ChangePasswordViewModel
    {
        [Required] [DataType(DataType.Password)]
        public string CurrentPassword { get; set; } = "";

        [Required, MinLength(8)]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; } = "";

        [Compare("NewPassword", ErrorMessage = "Passwords do not match")]
        [DataType(DataType.Password)]
        public string ConfirmNewPassword { get; set; } = "";
    }

    public class PaymentViewModel
    {
        public decimal Amount      { get; set; }
        public string Description  { get; set; } = "";
        public int? InvoiceId      { get; set; }

        // Card details (dummy)
        [Required] public string CardholderName { get; set; } = "";
        [Required, CreditCard] public string CardNumber { get; set; } = "";
        [Required] public string ExpiryMonth { get; set; } = "";
        [Required] public string ExpiryYear  { get; set; } = "";
        [Required, StringLength(4, MinimumLength = 3)]
        public string CVV { get; set; } = "";
        public string PaymentMethod { get; set; } = "CreditCard";
    }

    public class DashboardViewModel
    {
        public Student Student { get; set; } = new();
        public List<Enrollment> ActiveEnrollments { get; set; } = new();
        public List<Announcement> Announcements   { get; set; } = new();
        public List<Invoice> PendingInvoices       { get; set; } = new();
        public int TotalCredits  { get; set; }
        public decimal TotalFees { get; set; }
        public int TotalCourses  { get; set; }
    }

    public class ConflictCheckResult
    {
        public bool HasConflict { get; set; }
        public string Message   { get; set; } = "";
        public List<string> ConflictDetails { get; set; } = new();
    }
}
