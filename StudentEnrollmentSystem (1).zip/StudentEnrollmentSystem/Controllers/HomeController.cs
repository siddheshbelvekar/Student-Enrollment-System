using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using StudentEnrollmentSystem.Models;
using StudentEnrollmentSystem.Services;
using System.Security.Claims;

namespace StudentEnrollmentSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly StudentService    _studentService;
        private readonly EnrollmentService _enrollmentService;
        private readonly PaymentService    _paymentService;
        private readonly StatementService  _statementService;
        private readonly IConfiguration    _config;

        public HomeController(StudentService s, EnrollmentService e, PaymentService p,
                              StatementService st, IConfiguration c)
        {
            _studentService    = s;
            _enrollmentService = e;
            _paymentService    = p;
            _statementService  = st;
            _config = c;
        }

        public IActionResult Index()
        {
            if (User.Identity?.IsAuthenticated == true)
                return RedirectToAction("Dashboard");
            return View();
        }

        [Authorize]
        public async Task<IActionResult> Dashboard()
        {
            var studentId   = GetStudentId();
            var student     = await _studentService.GetByIdAsync(studentId);
            var semester    = _config["AppSettings:CurrentSemester"]!;
            var academicYear = _config["AppSettings:CurrentAcademicYear"]!;

            var enrollments  = await _enrollmentService.GetStudentEnrollmentsAsync(studentId, semester, academicYear);
            var announcements = await _statementService.GetAnnouncementsAsync();
            var invoices     = await _paymentService.GetStudentInvoicesAsync(studentId);

            var vm = new DashboardViewModel
            {
                Student           = student!,
                ActiveEnrollments = enrollments,
                Announcements     = announcements.Take(3).ToList(),
                PendingInvoices   = invoices.Where(i => i.Status == "Unpaid").ToList(),
                TotalCredits      = enrollments.Sum(e => e.Course?.Credits ?? 0),
                TotalFees         = enrollments.Sum(e => e.Course?.FeeAmount ?? 0),
                TotalCourses      = enrollments.Count
            };
            return View(vm);
        }

        public IActionResult Error() => View();

        private int GetStudentId() =>
            Convert.ToInt32(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
    }
}
