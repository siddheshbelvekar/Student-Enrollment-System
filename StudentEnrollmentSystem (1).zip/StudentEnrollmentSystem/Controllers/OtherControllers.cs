using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using StudentEnrollmentSystem.Models;
using StudentEnrollmentSystem.Services;
using System.Security.Claims;

namespace StudentEnrollmentSystem.Controllers
{
    // ─────────────────────────────────────────────────────────
    // AddDropController
    // ─────────────────────────────────────────────────────────
    [Authorize]
    public class AddDropController : Controller
    {
        private readonly EnrollmentService _enrollmentService;
        private readonly CourseService     _courseService;
        private readonly IConfiguration    _config;

        public AddDropController(EnrollmentService e, CourseService c, IConfiguration cfg)
        {
            _enrollmentService = e; _courseService = c; _config = cfg;
        }

        public async Task<IActionResult> Index()
        {
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;
            var enrollments = await _enrollmentService.GetStudentEnrollmentsAsync(GetStudentId(), sem, ay);
            var allCourses  = await _courseService.GetAllCoursesAsync(sem, ay);
            var enrolledIds = enrollments.Select(e => e.CourseId).ToHashSet();
            var available   = allCourses.Where(c => !enrolledIds.Contains(c.CourseId) && !c.IsFull).ToList();

            ViewBag.EnrolledCourses = enrollments;
            ViewBag.AvailableCourses = available;
            ViewBag.Semester = sem;
            ViewBag.AcademicYear = ay;
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Drop(int courseId, string reason)
        {
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;
            var (success, message) = await _enrollmentService.DropCourseAsync(GetStudentId(), courseId, reason, sem, ay);
            if (success) TempData["Success"] = message;
            else         TempData["Error"]   = message;
            return RedirectToAction("Index");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(int courseId)
        {
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;
            var (success, message) = await _enrollmentService.EnrollStudentAsync(GetStudentId(), courseId, sem, ay);
            if (success) TempData["Success"] = message;
            else         TempData["Error"]   = message;
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> History()
        {
            var history = await _enrollmentService.GetAddDropHistoryAsync(GetStudentId());
            return View(history);
        }

        private int GetStudentId() =>
            Convert.ToInt32(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
    }

    // ─────────────────────────────────────────────────────────
    // EnquiryController
    // ─────────────────────────────────────────────────────────
    public class EnquiryController : Controller
    {
        private readonly EnquiryService    _enquiryService;
        private readonly EnrollmentService _enrollmentService;
        private readonly CourseService     _courseService;
        private readonly IConfiguration    _config;

        public EnquiryController(EnquiryService e, EnrollmentService en, CourseService c, IConfiguration cfg)
        {
            _enquiryService = e; _enrollmentService = en; _courseService = c; _config = cfg;
        }

        // GET: /Enquiry/Contact
        public IActionResult Contact()
        {
            var model = new Enquiry();
            if (User.Identity?.IsAuthenticated == true)
            {
                model.FullName = User.Identity.Name ?? "";
                model.Email    = User.FindFirst(ClaimTypes.Email)?.Value ?? "";
            }
            return View(model);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Contact(Enquiry model)
        {
            if (!ModelState.IsValid) return View(model);
            if (User.Identity?.IsAuthenticated == true)
                model.StudentId = Convert.ToInt32(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

            await _enquiryService.SubmitEnquiryAsync(model);
            TempData["Success"] = "Your enquiry has been submitted. We will get back to you soon.";
            return RedirectToAction("Contact");
        }

        [Authorize]
        public async Task<IActionResult> MyEnquiries()
        {
            var enquiries = await _enquiryService.GetStudentEnquiriesAsync(GetStudentId());
            return View(enquiries);
        }

        [Authorize]
        public async Task<IActionResult> Timetable()
        {
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;
            var enrollments = await _enrollmentService.GetStudentEnrollmentsAsync(GetStudentId(), sem, ay);
            var allSlots = new List<CourseTimetable>();
            foreach (var e in enrollments)
            {
                var slots = await _courseService.GetCourseTimetablesAsync(e.CourseId);
                allSlots.AddRange(slots);
            }
            return View(allSlots);
        }

        [Authorize]
        public async Task<IActionResult> Feedback()
        {
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;
            var enrollments = await _enrollmentService.GetStudentEnrollmentsAsync(GetStudentId(), sem, ay);
            return View(enrollments);
        }

        [Authorize, HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> SubmitFeedback(Feedback model)
        {
            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Please fill all required fields.";
                return RedirectToAction("Feedback");
            }
            model.StudentId   = GetStudentId();
            model.Semester    = _config["AppSettings:CurrentSemester"]!;
            model.AcademicYear = _config["AppSettings:CurrentAcademicYear"]!;
            try
            {
                await _enquiryService.SubmitFeedbackAsync(model);
                TempData["Success"] = "Feedback submitted successfully. Thank you!";
            }
            catch (InvalidOperationException ex)
            {
                TempData["Error"] = ex.Message;
            }
            return RedirectToAction("Feedback");
        }

        private int GetStudentId() =>
            Convert.ToInt32(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
    }

    // ─────────────────────────────────────────────────────────
    // StatementController
    // ─────────────────────────────────────────────────────────
    [Authorize]
    public class StatementController : Controller
    {
        private readonly EnrollmentService _enrollmentService;
        private readonly PaymentService    _paymentService;
        private readonly StudentService    _studentService;
        private readonly CourseService     _courseService;
        private readonly IConfiguration    _config;

        public StatementController(EnrollmentService e, PaymentService p, StudentService s,
                                   CourseService c, IConfiguration cfg)
        {
            _enrollmentService = e; _paymentService = p; _studentService = s;
            _courseService = c; _config = cfg;
        }

        public async Task<IActionResult> Index()
        {
            var sid = GetStudentId();
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;
            var enrollments = await _enrollmentService.GetStudentEnrollmentsAsync(sid, sem, ay);
            var invoices    = await _paymentService.GetStudentInvoicesAsync(sid);
            var payments    = await _paymentService.GetPaymentHistoryAsync(sid);
            var student     = await _studentService.GetByIdAsync(sid);

            ViewBag.Enrollments  = enrollments;
            ViewBag.Invoices     = invoices;
            ViewBag.Payments     = payments;
            ViewBag.Student      = student;
            ViewBag.TotalFees    = enrollments.Sum(e => e.Course?.FeeAmount ?? 0);
            ViewBag.TotalPaid    = payments.Where(p => p.Status == "Completed").Sum(p => p.Amount);
            ViewBag.Semester     = sem;
            ViewBag.AcademicYear = ay;
            return View();
        }

        public async Task<IActionResult> RegistrationSummary()
        {
            var sid = GetStudentId();
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;
            var enrollments = await _enrollmentService.GetStudentEnrollmentsAsync(sid, sem, ay);
            var student     = await _studentService.GetByIdAsync(sid);
            ViewBag.Student  = student;
            ViewBag.Semester = sem;
            ViewBag.AcademicYear = ay;
            return View(enrollments);
        }

        public async Task<IActionResult> Timetable()
        {
            var sid = GetStudentId();
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;
            var enrollments = await _enrollmentService.GetStudentEnrollmentsAsync(sid, sem, ay);
            var allSlots    = new List<CourseTimetable>();
            foreach (var e in enrollments)
            {
                var slots = await _courseService.GetCourseTimetablesAsync(e.CourseId);
                allSlots.AddRange(slots);
            }
            return View(allSlots);
        }

        public async Task<IActionResult> Invoice(int id)
        {
            var invoice = await _paymentService.GetInvoiceByIdAsync(id);
            if (invoice == null || invoice.StudentId != GetStudentId()) return NotFound();
            return View(invoice);
        }

        private int GetStudentId() =>
            Convert.ToInt32(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
    }

    // ─────────────────────────────────────────────────────────
    // PaymentController
    // ─────────────────────────────────────────────────────────
    [Authorize]
    public class PaymentController : Controller
    {
        private readonly PaymentService    _paymentService;
        private readonly EnrollmentService _enrollmentService;
        private readonly IConfiguration    _config;

        public PaymentController(PaymentService p, EnrollmentService e, IConfiguration cfg)
        {
            _paymentService = p; _enrollmentService = e; _config = cfg;
        }

        public async Task<IActionResult> Index()
        {
            var sid = GetStudentId();
            var payments = await _paymentService.GetPaymentHistoryAsync(sid);
            var invoices = await _paymentService.GetStudentInvoicesAsync(sid);
            ViewBag.Invoices = invoices;
            return View(payments);
        }

        public async Task<IActionResult> Pay(int? invoiceId = null)
        {
            var sid = GetStudentId();
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;

            decimal amount = 0;
            string  desc   = "";

            if (invoiceId.HasValue)
            {
                var invoice = await _paymentService.GetInvoiceByIdAsync(invoiceId.Value);
                if (invoice != null && invoice.StudentId == sid)
                {
                    amount = invoice.TotalAmount;
                    desc   = $"Payment for Invoice {invoice.InvoiceNumber}";
                }
            }
            else
            {
                // Calculate from enrollments
                var enrollments = await _enrollmentService.GetStudentEnrollmentsAsync(sid, sem, ay);
                amount = enrollments.Sum(e => e.Course?.FeeAmount ?? 0);
                desc   = $"Tuition Fee - {sem} {ay}";
            }

            var vm = new PaymentViewModel { Amount = amount, Description = desc, InvoiceId = invoiceId };
            return View(vm);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Pay(PaymentViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var sid = GetStudentId();
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;

            var (success, message, reference) = await _paymentService.ProcessPaymentAsync(sid, model, sem, ay);

            if (!success)
            {
                TempData["Error"] = message;
                return View(model);
            }

            TempData["Success"]   = message;
            TempData["Reference"] = reference;
            return RedirectToAction("Receipt", new { reference });
        }

        public async Task<IActionResult> Receipt(string reference)
        {
            var payments = await _paymentService.GetPaymentHistoryAsync(GetStudentId());
            var payment  = payments.FirstOrDefault(p => p.PaymentReference == reference);
            if (payment == null) return NotFound();
            return View(payment);
        }

        private int GetStudentId() =>
            Convert.ToInt32(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
    }

    // ─────────────────────────────────────────────────────────
    // AdminController
    // ─────────────────────────────────────────────────────────
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly StudentService  _studentService;
        private readonly CourseService   _courseService;
        private readonly EnquiryService  _enquiryService;
        private readonly IConfiguration  _config;

        public AdminController(StudentService s, CourseService c, EnquiryService e, IConfiguration cfg)
        {
            _studentService = s; _courseService = c; _enquiryService = e; _config = cfg;
        }

        public async Task<IActionResult> Index()
        {
            var students  = await _studentService.GetAllStudentsAsync();
            var courses   = await _courseService.GetAllCoursesAsync();
            var enquiries = await _enquiryService.GetAllEnquiriesAsync();
            ViewBag.TotalStudents  = students.Count;
            ViewBag.TotalCourses   = courses.Count;
            ViewBag.PendingEnquiries = enquiries.Count(e => e.Status == "Pending");
            ViewBag.Enquiries      = enquiries.Take(10).ToList();
            return View();
        }

        public async Task<IActionResult> Students()
        {
            var students = await _studentService.GetAllStudentsAsync();
            return View(students);
        }

        public async Task<IActionResult> Courses()
        {
            var courses = await _courseService.GetAllCoursesAsync();
            return View(courses);
        }

        public async Task<IActionResult> Enquiries()
        {
            var enquiries = await _enquiryService.GetAllEnquiriesAsync();
            return View(enquiries);
        }
    }
}
