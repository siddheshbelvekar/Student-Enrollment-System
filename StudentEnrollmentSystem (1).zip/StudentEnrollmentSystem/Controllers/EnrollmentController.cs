using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using StudentEnrollmentSystem.Services;
using System.Security.Claims;

namespace StudentEnrollmentSystem.Controllers
{
    [Authorize]
    public class EnrollmentController : Controller
    {
        private readonly CourseService     _courseService;
        private readonly EnrollmentService _enrollmentService;
        private readonly IConfiguration    _config;

        public EnrollmentController(CourseService c, EnrollmentService e, IConfiguration cfg)
        {
            _courseService     = c;
            _enrollmentService = e;
            _config = cfg;
        }

        // GET: /Enrollment/Index - Browse Available Courses
        public async Task<IActionResult> Index()
        {
            var semester    = _config["AppSettings:CurrentSemester"]!;
            var academicYear = _config["AppSettings:CurrentAcademicYear"]!;
            var courses     = await _courseService.GetAllCoursesAsync(semester, academicYear);
            var enrolled    = await _enrollmentService.GetStudentEnrollmentsAsync(GetStudentId(), semester, academicYear);
            var enrolledIds = enrolled.Select(e => e.CourseId).ToHashSet();

            ViewBag.EnrolledCourseIds = enrolledIds;
            ViewBag.Semester    = semester;
            ViewBag.AcademicYear = academicYear;
            return View(courses);
        }

        // POST: /Enrollment/Enroll
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Enroll(int courseId)
        {
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;
            var (success, message) = await _enrollmentService.EnrollStudentAsync(GetStudentId(), courseId, sem, ay);

            if (success) TempData["Success"] = message;
            else         TempData["Error"]   = message;

            return RedirectToAction("Index");
        }

        // GET: /Enrollment/MyCourses
        public async Task<IActionResult> MyCourses()
        {
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;
            var enrollments = await _enrollmentService.GetStudentEnrollmentsAsync(GetStudentId(), sem, ay);
            return View(enrollments);
        }

        // GET: /Enrollment/CheckConflict?courseId=X
        public async Task<IActionResult> CheckConflict(int courseId)
        {
            var sem = _config["AppSettings:CurrentSemester"]!;
            var ay  = _config["AppSettings:CurrentAcademicYear"]!;
            var result = await _enrollmentService.CheckScheduleConflictAsync(GetStudentId(), courseId, sem, ay);
            return Json(result);
        }

        private int GetStudentId() =>
            Convert.ToInt32(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
    }
}
