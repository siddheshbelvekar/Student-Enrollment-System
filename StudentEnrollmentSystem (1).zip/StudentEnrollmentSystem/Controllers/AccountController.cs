using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using StudentEnrollmentSystem.Models;
using StudentEnrollmentSystem.Services;
using System.Security.Claims;

namespace StudentEnrollmentSystem.Controllers
{
    public class AccountController : Controller
    {
        private readonly StudentService _studentService;
        private readonly IConfiguration _config;

        public AccountController(StudentService studentService, IConfiguration config)
        {
            _studentService = studentService;
            _config = config;
        }

        // GET: /Account/Login
        public IActionResult Login(string? returnUrl = null)
        {
            if (User.Identity?.IsAuthenticated == true)
                return RedirectToAction("Dashboard", "Home");
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        // POST: /Account/Login
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
        {
            if (!ModelState.IsValid) return View(model);

            var student = await _studentService.AuthenticateAsync(model.Email, model.Password);
            if (student == null)
            {
                ModelState.AddModelError("", "Invalid email or password.");
                return View(model);
            }

            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, student.StudentId.ToString()),
                new(ClaimTypes.Name, student.FullName),
                new(ClaimTypes.Email, student.Email),
                new(ClaimTypes.Role, student.RoleName),
                new("StudentNumber", student.StudentNumber),
                new("Program", student.Program ?? "")
            };

            var identity  = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);
            var props     = new AuthenticationProperties { IsPersistent = model.RememberMe };

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, props);

            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);
            return RedirectToAction("Dashboard", "Home");
        }

        // GET: /Account/Register
        public IActionResult Register() => View();

        // POST: /Account/Register
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);
            var success = await _studentService.RegisterStudentAsync(model);
            if (!success)
            {
                ModelState.AddModelError("Email", "An account with this email already exists.");
                return View(model);
            }
            TempData["Success"] = "Registration successful! Please login.";
            return RedirectToAction("Login");
        }

        // POST: /Account/Logout
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }

        // GET: /Account/Profile
        [Authorize]
        public async Task<IActionResult> Profile()
        {
            var studentId = GetStudentId();
            var student = await _studentService.GetByIdAsync(studentId);
            return View(student);
        }

        // POST: /Account/Profile
        [Authorize, HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile(Student model)
        {
            ModelState.Remove("Email");
            ModelState.Remove("PasswordHash");
            ModelState.Remove("StudentNumber");
            if (!ModelState.IsValid) return View(model);

            model.StudentId = GetStudentId();
            await _studentService.UpdateProfileAsync(model);
            TempData["Success"] = "Profile updated successfully.";
            return RedirectToAction("Profile");
        }

        // GET: /Account/ChangePassword
        [Authorize]
        public IActionResult ChangePassword() => View();

        // POST: /Account/ChangePassword
        [Authorize, HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid) return View(model);
            var success = await _studentService.ChangePasswordAsync(GetStudentId(), model.CurrentPassword, model.NewPassword);
            if (!success)
            {
                ModelState.AddModelError("CurrentPassword", "Current password is incorrect.");
                return View(model);
            }
            TempData["Success"] = "Password changed successfully.";
            return RedirectToAction("ChangePassword");
        }

        // GET: /Account/BankDetails
        [Authorize]
        public async Task<IActionResult> BankDetails()
        {
            var details = await _studentService.GetBankDetailsAsync(GetStudentId());
            return View(details ?? new BankDetails { StudentId = GetStudentId() });
        }

        // POST: /Account/BankDetails
        [Authorize, HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> BankDetails(BankDetails model)
        {
            model.StudentId = GetStudentId();
            await _studentService.SaveBankDetailsAsync(model);
            TempData["Success"] = "Bank details updated successfully.";
            return RedirectToAction("BankDetails");
        }

        public IActionResult AccessDenied() => View();

        private int GetStudentId() =>
            Convert.ToInt32(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
    }
}
