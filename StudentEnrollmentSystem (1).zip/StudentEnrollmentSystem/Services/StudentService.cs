using Microsoft.Data.SqlClient;
using StudentEnrollmentSystem.Data;
using StudentEnrollmentSystem.Models;
using BCrypt.Net;

namespace StudentEnrollmentSystem.Services
{
    public class StudentService
    {
        private readonly DatabaseContext _db;

        public StudentService(DatabaseContext db) => _db = db;

        public async Task<Student?> AuthenticateAsync(string email, string password)
        {
            var rows = await _db.ExecuteQueryAsync(
                "SELECT s.*, r.RoleName FROM Students s JOIN Roles r ON s.RoleId = r.RoleId WHERE s.Email = @email AND s.IsActive = 1",
                new SqlParameter("@email", email));

            if (rows.Count == 0) return null;
            var row = rows[0];
            var hash = row["PasswordHash"]?.ToString() ?? "";

            if (!BCrypt.Net.BCrypt.Verify(password, hash)) return null;
            return MapStudent(row);
        }

        public async Task<Student?> GetByIdAsync(int studentId)
        {
            var rows = await _db.ExecuteQueryAsync(
                "SELECT s.*, r.RoleName FROM Students s JOIN Roles r ON s.RoleId = r.RoleId WHERE s.StudentId = @id",
                new SqlParameter("@id", studentId));
            return rows.Count > 0 ? MapStudent(rows[0]) : null;
        }

        public async Task<List<Student>> GetAllStudentsAsync()
        {
            var rows = await _db.ExecuteQueryAsync(
                "SELECT s.*, r.RoleName FROM Students s JOIN Roles r ON s.RoleId = r.RoleId WHERE s.RoleId = 2 ORDER BY s.LastName, s.FirstName");
            return rows.Select(MapStudent).ToList();
        }

        public async Task<bool> RegisterStudentAsync(RegisterViewModel model)
        {
            // Check email uniqueness
            var existing = await _db.ExecuteScalarAsync("SELECT COUNT(*) FROM Students WHERE Email = @email",
                new SqlParameter("@email", model.Email));
            if (Convert.ToInt32(existing) > 0) return false;

            var studentNumber = await GenerateStudentNumberAsync();
            var hash = BCrypt.Net.BCrypt.HashPassword(model.Password);

            await _db.ExecuteNonQueryAsync(
                @"INSERT INTO Students (StudentNumber, FirstName, LastName, Email, PasswordHash, PhoneNumber, Program, RoleId)
                  VALUES (@sn, @fn, @ln, @email, @hash, @phone, @prog, 2)",
                new SqlParameter("@sn",    studentNumber),
                new SqlParameter("@fn",    model.FirstName),
                new SqlParameter("@ln",    model.LastName),
                new SqlParameter("@email", model.Email),
                new SqlParameter("@hash",  hash),
                new SqlParameter("@phone", (object?)model.PhoneNumber ?? DBNull.Value),
                new SqlParameter("@prog",  (object?)model.Program ?? DBNull.Value));
            return true;
        }

        public async Task<bool> ChangePasswordAsync(int studentId, string currentPwd, string newPwd)
        {
            var rows = await _db.ExecuteQueryAsync("SELECT PasswordHash FROM Students WHERE StudentId = @id",
                new SqlParameter("@id", studentId));
            if (rows.Count == 0) return false;

            var currentHash = rows[0]["PasswordHash"]?.ToString() ?? "";
            if (!BCrypt.Net.BCrypt.Verify(currentPwd, currentHash)) return false;

            var newHash = BCrypt.Net.BCrypt.HashPassword(newPwd);
            await _db.ExecuteNonQueryAsync(
                "UPDATE Students SET PasswordHash = @hash, UpdatedAt = GETDATE() WHERE StudentId = @id",
                new SqlParameter("@hash", newHash),
                new SqlParameter("@id",   studentId));
            return true;
        }

        public async Task UpdateProfileAsync(Student student)
        {
            await _db.ExecuteNonQueryAsync(
                @"UPDATE Students SET FirstName=@fn, LastName=@ln, PhoneNumber=@phone,
                  DateOfBirth=@dob, Address=@addr, Program=@prog, YearLevel=@yr, UpdatedAt=GETDATE()
                  WHERE StudentId=@id",
                new SqlParameter("@fn",    student.FirstName),
                new SqlParameter("@ln",    student.LastName),
                new SqlParameter("@phone", (object?)student.PhoneNumber ?? DBNull.Value),
                new SqlParameter("@dob",   (object?)student.DateOfBirth ?? DBNull.Value),
                new SqlParameter("@addr",  (object?)student.Address ?? DBNull.Value),
                new SqlParameter("@prog",  (object?)student.Program ?? DBNull.Value),
                new SqlParameter("@yr",    student.YearLevel),
                new SqlParameter("@id",    student.StudentId));
        }

        public async Task<BankDetails?> GetBankDetailsAsync(int studentId)
        {
            var rows = await _db.ExecuteQueryAsync("SELECT * FROM BankDetails WHERE StudentId = @id",
                new SqlParameter("@id", studentId));
            if (rows.Count == 0) return null;
            var r = rows[0];
            return new BankDetails
            {
                BankDetailId = Convert.ToInt32(r["BankDetailId"]),
                StudentId    = Convert.ToInt32(r["StudentId"]),
                BankName     = r["BankName"]?.ToString(),
                AccountHolderName = r["AccountHolderName"]?.ToString(),
                AccountNumber     = r["AccountNumber"]?.ToString(),
                RoutingNumber     = r["RoutingNumber"]?.ToString(),
                AccountType       = r["AccountType"]?.ToString(),
                UpdatedAt         = Convert.ToDateTime(r["UpdatedAt"])
            };
        }

        public async Task SaveBankDetailsAsync(BankDetails details)
        {
            var existing = await _db.ExecuteScalarAsync("SELECT COUNT(*) FROM BankDetails WHERE StudentId = @id",
                new SqlParameter("@id", details.StudentId));

            if (Convert.ToInt32(existing) > 0)
            {
                await _db.ExecuteNonQueryAsync(
                    @"UPDATE BankDetails SET BankName=@bn, AccountHolderName=@ahn, AccountNumber=@an,
                      RoutingNumber=@rn, AccountType=@at, UpdatedAt=GETDATE() WHERE StudentId=@id",
                    new SqlParameter("@bn",  (object?)details.BankName ?? DBNull.Value),
                    new SqlParameter("@ahn", (object?)details.AccountHolderName ?? DBNull.Value),
                    new SqlParameter("@an",  (object?)details.AccountNumber ?? DBNull.Value),
                    new SqlParameter("@rn",  (object?)details.RoutingNumber ?? DBNull.Value),
                    new SqlParameter("@at",  (object?)details.AccountType ?? DBNull.Value),
                    new SqlParameter("@id",  details.StudentId));
            }
            else
            {
                await _db.ExecuteNonQueryAsync(
                    @"INSERT INTO BankDetails (StudentId, BankName, AccountHolderName, AccountNumber, RoutingNumber, AccountType)
                      VALUES (@id, @bn, @ahn, @an, @rn, @at)",
                    new SqlParameter("@id",  details.StudentId),
                    new SqlParameter("@bn",  (object?)details.BankName ?? DBNull.Value),
                    new SqlParameter("@ahn", (object?)details.AccountHolderName ?? DBNull.Value),
                    new SqlParameter("@an",  (object?)details.AccountNumber ?? DBNull.Value),
                    new SqlParameter("@rn",  (object?)details.RoutingNumber ?? DBNull.Value),
                    new SqlParameter("@at",  (object?)details.AccountType ?? DBNull.Value));
            }
        }

        private async Task<string> GenerateStudentNumberAsync()
        {
            var year = DateTime.Now.Year;
            var count = await _db.ExecuteScalarAsync(
                "SELECT COUNT(*) FROM Students WHERE StudentNumber LIKE @prefix",
                new SqlParameter("@prefix", $"STU{year}%"));
            return $"STU{year}{(Convert.ToInt32(count) + 1):D3}";
        }

        private static Student MapStudent(Dictionary<string, object?> r) => new()
        {
            StudentId     = Convert.ToInt32(r["StudentId"]),
            StudentNumber = r["StudentNumber"]?.ToString() ?? "",
            FirstName     = r["FirstName"]?.ToString() ?? "",
            LastName      = r["LastName"]?.ToString() ?? "",
            Email         = r["Email"]?.ToString() ?? "",
            PasswordHash  = r["PasswordHash"]?.ToString() ?? "",
            PhoneNumber   = r["PhoneNumber"]?.ToString(),
            DateOfBirth   = r["DateOfBirth"] == null ? null : Convert.ToDateTime(r["DateOfBirth"]),
            Address       = r["Address"]?.ToString(),
            Program       = r["Program"]?.ToString(),
            YearLevel     = r["YearLevel"] == null ? 1 : Convert.ToInt32(r["YearLevel"]),
            RoleId        = Convert.ToInt32(r["RoleId"]),
            RoleName      = r["RoleName"]?.ToString() ?? "Student",
            IsActive      = Convert.ToBoolean(r["IsActive"]),
            CreatedAt     = Convert.ToDateTime(r["CreatedAt"]),
            UpdatedAt     = Convert.ToDateTime(r["UpdatedAt"])
        };
    }
}
