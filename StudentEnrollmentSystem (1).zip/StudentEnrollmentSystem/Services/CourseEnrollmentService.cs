using Microsoft.Data.SqlClient;
using StudentEnrollmentSystem.Data;
using StudentEnrollmentSystem.Models;

namespace StudentEnrollmentSystem.Services
{
    // ─────────────────────────────────────────────────────────
    // CourseService
    // ─────────────────────────────────────────────────────────
    public class CourseService
    {
        private readonly DatabaseContext _db;
        public CourseService(DatabaseContext db) => _db = db;

        public async Task<List<Course>> GetAllCoursesAsync(string? semester = null, string? academicYear = null)
        {
            var sql = "SELECT * FROM Courses WHERE IsActive = 1";
            var p = new List<SqlParameter>();
            if (!string.IsNullOrEmpty(semester))
            { sql += " AND Semester = @sem"; p.Add(new SqlParameter("@sem", semester)); }
            if (!string.IsNullOrEmpty(academicYear))
            { sql += " AND AcademicYear = @ay"; p.Add(new SqlParameter("@ay", academicYear)); }
            sql += " ORDER BY Department, CourseCode";

            var rows = await _db.ExecuteQueryAsync(sql, p.ToArray());
            var courses = rows.Select(MapCourse).ToList();

            // Load timetables
            foreach (var c in courses)
                c.Timetables = await GetCourseTimetablesAsync(c.CourseId);

            return courses;
        }

        public async Task<Course?> GetCourseByIdAsync(int courseId)
        {
            var rows = await _db.ExecuteQueryAsync("SELECT * FROM Courses WHERE CourseId = @id",
                new SqlParameter("@id", courseId));
            if (rows.Count == 0) return null;
            var course = MapCourse(rows[0]);
            course.Timetables = await GetCourseTimetablesAsync(courseId);
            return course;
        }

        public async Task<List<CourseTimetable>> GetCourseTimetablesAsync(int courseId)
        {
            var rows = await _db.ExecuteQueryAsync(
                "SELECT ct.*, c.CourseName, c.CourseCode FROM CourseTimetable ct JOIN Courses c ON ct.CourseId = c.CourseId WHERE ct.CourseId = @id ORDER BY ct.DayOfWeek, ct.StartTime",
                new SqlParameter("@id", courseId));
            return rows.Select(r => new CourseTimetable
            {
                TimetableId = Convert.ToInt32(r["TimetableId"]),
                CourseId    = Convert.ToInt32(r["CourseId"]),
                DayOfWeek   = r["DayOfWeek"]?.ToString() ?? "",
                StartTime   = TimeSpan.Parse(r["StartTime"]!.ToString()!),
                EndTime     = TimeSpan.Parse(r["EndTime"]!.ToString()!),
                Room        = r["Room"]?.ToString(),
                Building    = r["Building"]?.ToString(),
                CourseName  = r["CourseName"]?.ToString() ?? "",
                CourseCode  = r["CourseCode"]?.ToString() ?? ""
            }).ToList();
        }

        private static Course MapCourse(Dictionary<string, object?> r) => new()
        {
            CourseId        = Convert.ToInt32(r["CourseId"]),
            CourseCode      = r["CourseCode"]?.ToString() ?? "",
            CourseName      = r["CourseName"]?.ToString() ?? "",
            Description     = r["Description"]?.ToString(),
            Credits         = Convert.ToInt32(r["Credits"]),
            MaxCapacity     = Convert.ToInt32(r["MaxCapacity"]),
            CurrentEnrolled = Convert.ToInt32(r["CurrentEnrolled"]),
            Instructor      = r["Instructor"]?.ToString(),
            Department      = r["Department"]?.ToString(),
            Semester        = r["Semester"]?.ToString(),
            AcademicYear    = r["AcademicYear"]?.ToString(),
            FeeAmount       = Convert.ToDecimal(r["FeeAmount"]),
            IsActive        = Convert.ToBoolean(r["IsActive"]),
            CreatedAt       = Convert.ToDateTime(r["CreatedAt"])
        };
    }

    // ─────────────────────────────────────────────────────────
    // EnrollmentService
    // ─────────────────────────────────────────────────────────
    public class EnrollmentService
    {
        private readonly DatabaseContext _db;
        private readonly CourseService   _courseService;

        public EnrollmentService(DatabaseContext db, CourseService courseService)
        {
            _db = db;
            _courseService = courseService;
        }

        public async Task<List<Enrollment>> GetStudentEnrollmentsAsync(int studentId, string? semester = null, string? academicYear = null)
        {
            var sql = @"SELECT e.*, c.CourseCode, c.CourseName, c.Credits, c.Instructor,
                               c.Department, c.FeeAmount, c.MaxCapacity, c.CurrentEnrolled,
                               c.Semester AS CourseSemester, c.AcademicYear AS CourseAcademicYear,
                               c.IsActive, c.Description, c.CreatedAt AS CourseCreatedAt
                        FROM Enrollments e JOIN Courses c ON e.CourseId = c.CourseId
                        WHERE e.StudentId = @sid AND e.Status = 'Active'";
            var p = new List<SqlParameter> { new("@sid", studentId) };
            if (!string.IsNullOrEmpty(semester))
            { sql += " AND e.Semester = @sem"; p.Add(new SqlParameter("@sem", semester)); }
            if (!string.IsNullOrEmpty(academicYear))
            { sql += " AND e.AcademicYear = @ay"; p.Add(new SqlParameter("@ay", academicYear)); }

            var rows = await _db.ExecuteQueryAsync(sql, p.ToArray());
            return rows.Select(r => new Enrollment
            {
                EnrollmentId   = Convert.ToInt32(r["EnrollmentId"]),
                StudentId      = Convert.ToInt32(r["StudentId"]),
                CourseId       = Convert.ToInt32(r["CourseId"]),
                EnrollmentDate = Convert.ToDateTime(r["EnrollmentDate"]),
                Status         = r["Status"]?.ToString() ?? "",
                Grade          = r["Grade"]?.ToString(),
                Semester       = r["Semester"]?.ToString(),
                AcademicYear   = r["AcademicYear"]?.ToString(),
                Course = new Course
                {
                    CourseId        = Convert.ToInt32(r["CourseId"]),
                    CourseCode      = r["CourseCode"]?.ToString() ?? "",
                    CourseName      = r["CourseName"]?.ToString() ?? "",
                    Credits         = Convert.ToInt32(r["Credits"]),
                    Instructor      = r["Instructor"]?.ToString(),
                    Department      = r["Department"]?.ToString(),
                    FeeAmount       = Convert.ToDecimal(r["FeeAmount"]),
                    MaxCapacity     = Convert.ToInt32(r["MaxCapacity"]),
                    CurrentEnrolled = Convert.ToInt32(r["CurrentEnrolled"]),
                    Description     = r["Description"]?.ToString(),
                    IsActive        = Convert.ToBoolean(r["IsActive"])
                }
            }).ToList();
        }

        public async Task<(bool Success, string Message)> EnrollStudentAsync(int studentId, int courseId, string semester, string academicYear)
        {
            // Check already enrolled
            var exists = await _db.ExecuteScalarAsync(
                "SELECT COUNT(*) FROM Enrollments WHERE StudentId=@sid AND CourseId=@cid AND Semester=@sem AND AcademicYear=@ay AND Status='Active'",
                new SqlParameter("@sid", studentId), new SqlParameter("@cid", courseId),
                new SqlParameter("@sem", semester),  new SqlParameter("@ay",  academicYear));
            if (Convert.ToInt32(exists) > 0)
                return (false, "You are already enrolled in this course.");

            // Check capacity
            var course = await _courseService.GetCourseByIdAsync(courseId);
            if (course == null) return (false, "Course not found.");
            if (course.IsFull) return (false, "This course is full.");

            // Check schedule conflicts
            var conflict = await CheckScheduleConflictAsync(studentId, courseId, semester, academicYear);
            if (conflict.HasConflict) return (false, conflict.Message);

            // Enroll
            await _db.ExecuteNonQueryAsync(
                "INSERT INTO Enrollments (StudentId, CourseId, Semester, AcademicYear) VALUES (@sid, @cid, @sem, @ay)",
                new SqlParameter("@sid", studentId), new SqlParameter("@cid", courseId),
                new SqlParameter("@sem", semester),  new SqlParameter("@ay",  academicYear));

            // Increment count
            await _db.ExecuteNonQueryAsync(
                "UPDATE Courses SET CurrentEnrolled = CurrentEnrolled + 1 WHERE CourseId = @cid",
                new SqlParameter("@cid", courseId));

            // Log history
            await LogAddDropHistoryAsync(studentId, courseId, "Add", "Online enrollment", semester, academicYear);

            return (true, $"Successfully enrolled in {course.CourseName}.");
        }

        public async Task<(bool Success, string Message)> DropCourseAsync(int studentId, int courseId, string reason, string semester, string academicYear)
        {
            var exists = await _db.ExecuteScalarAsync(
                "SELECT COUNT(*) FROM Enrollments WHERE StudentId=@sid AND CourseId=@cid AND Semester=@sem AND AcademicYear=@ay AND Status='Active'",
                new SqlParameter("@sid", studentId), new SqlParameter("@cid", courseId),
                new SqlParameter("@sem", semester),  new SqlParameter("@ay",  academicYear));
            if (Convert.ToInt32(exists) == 0)
                return (false, "You are not enrolled in this course.");

            await _db.ExecuteNonQueryAsync(
                "UPDATE Enrollments SET Status='Dropped' WHERE StudentId=@sid AND CourseId=@cid AND Semester=@sem AND AcademicYear=@ay",
                new SqlParameter("@sid", studentId), new SqlParameter("@cid", courseId),
                new SqlParameter("@sem", semester),  new SqlParameter("@ay",  academicYear));

            await _db.ExecuteNonQueryAsync(
                "UPDATE Courses SET CurrentEnrolled = CurrentEnrolled - 1 WHERE CourseId = @cid AND CurrentEnrolled > 0",
                new SqlParameter("@cid", courseId));

            await LogAddDropHistoryAsync(studentId, courseId, "Drop", reason, semester, academicYear);

            return (true, "Course dropped successfully.");
        }

        public async Task<List<AddDropHistory>> GetAddDropHistoryAsync(int studentId)
        {
            var rows = await _db.ExecuteQueryAsync(
                @"SELECT adh.*, c.CourseCode, c.CourseName FROM AddDropHistory adh
                  JOIN Courses c ON adh.CourseId = c.CourseId
                  WHERE adh.StudentId = @sid ORDER BY adh.ActionDate DESC",
                new SqlParameter("@sid", studentId));
            return rows.Select(r => new AddDropHistory
            {
                HistoryId    = Convert.ToInt32(r["HistoryId"]),
                StudentId    = Convert.ToInt32(r["StudentId"]),
                CourseId     = Convert.ToInt32(r["CourseId"]),
                ActionType   = r["ActionType"]?.ToString() ?? "",
                ActionDate   = Convert.ToDateTime(r["ActionDate"]),
                Reason       = r["Reason"]?.ToString(),
                Semester     = r["Semester"]?.ToString(),
                AcademicYear = r["AcademicYear"]?.ToString(),
                CourseCode   = r["CourseCode"]?.ToString() ?? "",
                CourseName   = r["CourseName"]?.ToString() ?? ""
            }).ToList();
        }

        public async Task<ConflictCheckResult> CheckScheduleConflictAsync(int studentId, int newCourseId, string semester, string academicYear)
        {
            var result = new ConflictCheckResult();

            // Get new course timetable
            var newTimetables = await _courseService.GetCourseTimetablesAsync(newCourseId);

            // Get student's current timetables
            var enrolledCourseIds = (await _db.ExecuteQueryAsync(
                "SELECT CourseId FROM Enrollments WHERE StudentId=@sid AND Status='Active' AND Semester=@sem AND AcademicYear=@ay",
                new SqlParameter("@sid", studentId), new SqlParameter("@sem", semester), new SqlParameter("@ay", academicYear)))
                .Select(r => Convert.ToInt32(r["CourseId"])).ToList();

            foreach (var cid in enrolledCourseIds)
            {
                var existing = await _courseService.GetCourseTimetablesAsync(cid);
                foreach (var newSlot in newTimetables)
                {
                    foreach (var existSlot in existing)
                    {
                        if (existSlot.DayOfWeek == newSlot.DayOfWeek &&
                            newSlot.StartTime < existSlot.EndTime &&
                            newSlot.EndTime > existSlot.StartTime)
                        {
                            result.HasConflict = true;
                            result.ConflictDetails.Add(
                                $"Conflict on {newSlot.DayOfWeek}: New course {newSlot.TimeRange} overlaps with {existSlot.CourseCode} ({existSlot.TimeRange})");
                        }
                    }
                }
            }

            result.Message = result.HasConflict
                ? "Schedule conflict detected: " + string.Join("; ", result.ConflictDetails)
                : "No conflicts found.";

            return result;
        }

        private async Task LogAddDropHistoryAsync(int studentId, int courseId, string actionType, string reason, string semester, string academicYear)
        {
            await _db.ExecuteNonQueryAsync(
                @"INSERT INTO AddDropHistory (StudentId, CourseId, ActionType, Reason, Semester, AcademicYear)
                  VALUES (@sid, @cid, @at, @reason, @sem, @ay)",
                new SqlParameter("@sid",    studentId),
                new SqlParameter("@cid",    courseId),
                new SqlParameter("@at",     actionType),
                new SqlParameter("@reason", (object?)reason ?? DBNull.Value),
                new SqlParameter("@sem",    semester),
                new SqlParameter("@ay",     academicYear));
        }
    }
}
