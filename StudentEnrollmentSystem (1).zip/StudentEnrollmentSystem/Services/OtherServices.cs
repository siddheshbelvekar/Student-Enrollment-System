using Microsoft.Data.SqlClient;
using StudentEnrollmentSystem.Data;
using StudentEnrollmentSystem.Models;

namespace StudentEnrollmentSystem.Services
{
    // ─────────────────────────────────────────────────────────
    // PaymentService
    // ─────────────────────────────────────────────────────────
    public class PaymentService
    {
        private readonly DatabaseContext _db;
        public PaymentService(DatabaseContext db) => _db = db;

        public async Task<List<Invoice>> GetStudentInvoicesAsync(int studentId)
        {
            var rows = await _db.ExecuteQueryAsync(
                "SELECT * FROM Invoices WHERE StudentId = @sid ORDER BY IssuedDate DESC",
                new SqlParameter("@sid", studentId));
            var invoices = rows.Select(MapInvoice).ToList();
            foreach (var inv in invoices)
                inv.Items = await GetInvoiceItemsAsync(inv.InvoiceId);
            return invoices;
        }

        public async Task<Invoice?> GetInvoiceByIdAsync(int invoiceId)
        {
            var rows = await _db.ExecuteQueryAsync(
                @"SELECT i.*, s.FirstName, s.LastName, s.StudentNumber, s.Email
                  FROM Invoices i JOIN Students s ON i.StudentId = s.StudentId
                  WHERE i.InvoiceId = @id",
                new SqlParameter("@id", invoiceId));
            if (rows.Count == 0) return null;
            var inv = MapInvoice(rows[0]);
            inv.Items = await GetInvoiceItemsAsync(invoiceId);
            inv.Student = new Student
            {
                FirstName     = rows[0]["FirstName"]?.ToString() ?? "",
                LastName      = rows[0]["LastName"]?.ToString() ?? "",
                StudentNumber = rows[0]["StudentNumber"]?.ToString() ?? "",
                Email         = rows[0]["Email"]?.ToString() ?? ""
            };
            return inv;
        }

        public async Task<List<InvoiceItem>> GetInvoiceItemsAsync(int invoiceId)
        {
            var rows = await _db.ExecuteQueryAsync(
                "SELECT * FROM InvoiceItems WHERE InvoiceId = @id",
                new SqlParameter("@id", invoiceId));
            return rows.Select(r => new InvoiceItem
            {
                ItemId      = Convert.ToInt32(r["ItemId"]),
                InvoiceId   = Convert.ToInt32(r["InvoiceId"]),
                CourseId    = r["CourseId"] == null ? null : Convert.ToInt32(r["CourseId"]),
                Description = r["Description"]?.ToString() ?? "",
                Quantity    = Convert.ToInt32(r["Quantity"]),
                UnitPrice   = Convert.ToDecimal(r["UnitPrice"]),
                TotalPrice  = Convert.ToDecimal(r["TotalPrice"])
            }).ToList();
        }

        public async Task<List<Payment>> GetPaymentHistoryAsync(int studentId)
        {
            var rows = await _db.ExecuteQueryAsync(
                "SELECT * FROM Payments WHERE StudentId = @sid ORDER BY PaymentDate DESC",
                new SqlParameter("@sid", studentId));
            return rows.Select(MapPayment).ToList();
        }

        public async Task<(bool Success, string Message, string? Reference)> ProcessPaymentAsync(
            int studentId, PaymentViewModel model, string semester, string academicYear)
        {
            // Simulate payment processing (dummy gateway)
            await Task.Delay(500); // Simulate API call

            // Validate card (basic dummy validation)
            var cardNumber = model.CardNumber.Replace(" ", "").Replace("-", "");
            if (cardNumber.Length < 13 || cardNumber.Length > 19)
                return (false, "Invalid card number.", null);

            // Simulate success/failure (95% success rate)
            var random = new Random();
            if (random.Next(1, 21) == 1) // 5% failure
                return (false, "Payment declined by gateway. Please try again.", null);

            var reference = $"PAY-{DateTime.Now.Year}-{DateTime.Now:MMddHHmmss}";
            var lastFour  = cardNumber[^4..];

            // Save payment
            await _db.ExecuteNonQueryAsync(
                @"INSERT INTO Payments (StudentId, PaymentReference, Amount, PaymentMethod, CardLastFour, Status, Description, Semester, AcademicYear)
                  VALUES (@sid, @ref, @amt, @pm, @last4, 'Completed', @desc, @sem, @ay)",
                new SqlParameter("@sid",   studentId),
                new SqlParameter("@ref",   reference),
                new SqlParameter("@amt",   model.Amount),
                new SqlParameter("@pm",    model.PaymentMethod),
                new SqlParameter("@last4", lastFour),
                new SqlParameter("@desc",  model.Description),
                new SqlParameter("@sem",   semester),
                new SqlParameter("@ay",    academicYear));

            return (true, "Payment processed successfully.", reference);
        }

        public async Task<Invoice> GenerateInvoiceAsync(int studentId, List<(int CourseId, string Desc, decimal Fee)> items,
            string semester, string academicYear)
        {
            var invoiceNumber = $"INV-{DateTime.Now.Year}-{DateTime.Now:MMddHHmmss}";
            var subTotal = items.Sum(i => i.Fee);
            var dueDate  = DateTime.Now.AddDays(30);

            var invoiceId = Convert.ToInt32(await _db.ExecuteScalarAsync(
                @"INSERT INTO Invoices (InvoiceNumber, StudentId, SubTotal, TotalAmount, Status, DueDate, Semester, AcademicYear)
                  OUTPUT INSERTED.InvoiceId
                  VALUES (@num, @sid, @sub, @total, 'Unpaid', @due, @sem, @ay)",
                new SqlParameter("@num",   invoiceNumber),
                new SqlParameter("@sid",   studentId),
                new SqlParameter("@sub",   subTotal),
                new SqlParameter("@total", subTotal),
                new SqlParameter("@due",   dueDate),
                new SqlParameter("@sem",   semester),
                new SqlParameter("@ay",    academicYear)));

            foreach (var (courseId, desc, fee) in items)
            {
                await _db.ExecuteNonQueryAsync(
                    "INSERT INTO InvoiceItems (InvoiceId, CourseId, Description, UnitPrice, TotalPrice) VALUES (@iid, @cid, @desc, @price, @price)",
                    new SqlParameter("@iid",   invoiceId),
                    new SqlParameter("@cid",   courseId),
                    new SqlParameter("@desc",  desc),
                    new SqlParameter("@price", fee));
            }

            return (await GetInvoiceByIdAsync(invoiceId))!;
        }

        private static Invoice MapInvoice(Dictionary<string, object?> r) => new()
        {
            InvoiceId     = Convert.ToInt32(r["InvoiceId"]),
            InvoiceNumber = r["InvoiceNumber"]?.ToString() ?? "",
            StudentId     = Convert.ToInt32(r["StudentId"]),
            PaymentId     = r["PaymentId"] == null ? null : Convert.ToInt32(r["PaymentId"]),
            SubTotal      = Convert.ToDecimal(r["SubTotal"]),
            Discount      = Convert.ToDecimal(r["Discount"]),
            Tax           = Convert.ToDecimal(r["Tax"]),
            TotalAmount   = Convert.ToDecimal(r["TotalAmount"]),
            Status        = r["Status"]?.ToString() ?? "",
            DueDate       = r["DueDate"] == null ? null : Convert.ToDateTime(r["DueDate"]),
            IssuedDate    = Convert.ToDateTime(r["IssuedDate"]),
            PaidDate      = r["PaidDate"] == null ? null : Convert.ToDateTime(r["PaidDate"]),
            Notes         = r["Notes"]?.ToString(),
            Semester      = r["Semester"]?.ToString(),
            AcademicYear  = r["AcademicYear"]?.ToString()
        };

        private static Payment MapPayment(Dictionary<string, object?> r) => new()
        {
            PaymentId        = Convert.ToInt32(r["PaymentId"]),
            StudentId        = Convert.ToInt32(r["StudentId"]),
            PaymentReference = r["PaymentReference"]?.ToString() ?? "",
            Amount           = Convert.ToDecimal(r["Amount"]),
            PaymentMethod    = r["PaymentMethod"]?.ToString(),
            CardLastFour     = r["CardLastFour"]?.ToString(),
            PaymentDate      = Convert.ToDateTime(r["PaymentDate"]),
            Status           = r["Status"]?.ToString() ?? "",
            Description      = r["Description"]?.ToString(),
            Semester         = r["Semester"]?.ToString(),
            AcademicYear     = r["AcademicYear"]?.ToString()
        };
    }

    // ─────────────────────────────────────────────────────────
    // EnquiryService
    // ─────────────────────────────────────────────────────────
    public class EnquiryService
    {
        private readonly DatabaseContext _db;
        public EnquiryService(DatabaseContext db) => _db = db;

        public async Task SubmitEnquiryAsync(Enquiry enquiry)
        {
            await _db.ExecuteNonQueryAsync(
                @"INSERT INTO Enquiries (StudentId, FullName, Email, Subject, Message)
                  VALUES (@sid, @fn, @em, @sub, @msg)",
                new SqlParameter("@sid", (object?)enquiry.StudentId ?? DBNull.Value),
                new SqlParameter("@fn",  enquiry.FullName),
                new SqlParameter("@em",  enquiry.Email),
                new SqlParameter("@sub", enquiry.Subject),
                new SqlParameter("@msg", enquiry.Message));
        }

        public async Task SubmitFeedbackAsync(Feedback feedback)
        {
            // Check if already submitted
            var exists = await _db.ExecuteScalarAsync(
                "SELECT COUNT(*) FROM Feedback WHERE StudentId=@sid AND CourseId=@cid AND Semester=@sem AND AcademicYear=@ay",
                new SqlParameter("@sid", feedback.StudentId),
                new SqlParameter("@cid", feedback.CourseId),
                new SqlParameter("@sem", feedback.Semester ?? ""),
                new SqlParameter("@ay",  feedback.AcademicYear ?? ""));
            if (Convert.ToInt32(exists) > 0)
                throw new InvalidOperationException("You have already submitted feedback for this course.");

            await _db.ExecuteNonQueryAsync(
                @"INSERT INTO Feedback (StudentId, CourseId, TeachingRating, ContentRating, MaterialRating, OverallRating, Comments, IsAnonymous, Semester, AcademicYear)
                  VALUES (@sid, @cid, @tr, @cr, @mr, @or, @comments, @anon, @sem, @ay)",
                new SqlParameter("@sid",      feedback.StudentId),
                new SqlParameter("@cid",      feedback.CourseId),
                new SqlParameter("@tr",       feedback.TeachingRating),
                new SqlParameter("@cr",       feedback.ContentRating),
                new SqlParameter("@mr",       feedback.MaterialRating),
                new SqlParameter("@or",       feedback.OverallRating),
                new SqlParameter("@comments", (object?)feedback.Comments ?? DBNull.Value),
                new SqlParameter("@anon",     feedback.IsAnonymous),
                new SqlParameter("@sem",      feedback.Semester ?? ""),
                new SqlParameter("@ay",       feedback.AcademicYear ?? ""));
        }

        public async Task<List<Enquiry>> GetStudentEnquiriesAsync(int studentId)
        {
            var rows = await _db.ExecuteQueryAsync(
                "SELECT * FROM Enquiries WHERE StudentId = @sid ORDER BY SubmittedAt DESC",
                new SqlParameter("@sid", studentId));
            return rows.Select(MapEnquiry).ToList();
        }

        public async Task<List<Enquiry>> GetAllEnquiriesAsync()
        {
            var rows = await _db.ExecuteQueryAsync("SELECT * FROM Enquiries ORDER BY SubmittedAt DESC");
            return rows.Select(MapEnquiry).ToList();
        }

        private static Enquiry MapEnquiry(Dictionary<string, object?> r) => new()
        {
            EnquiryId   = Convert.ToInt32(r["EnquiryId"]),
            StudentId   = r["StudentId"] == null ? null : Convert.ToInt32(r["StudentId"]),
            FullName    = r["FullName"]?.ToString() ?? "",
            Email       = r["Email"]?.ToString() ?? "",
            Subject     = r["Subject"]?.ToString() ?? "",
            Message     = r["Message"]?.ToString() ?? "",
            Status      = r["Status"]?.ToString() ?? "",
            AdminReply  = r["AdminReply"]?.ToString(),
            SubmittedAt = Convert.ToDateTime(r["SubmittedAt"]),
            RepliedAt   = r["RepliedAt"] == null ? null : Convert.ToDateTime(r["RepliedAt"])
        };
    }

    // ─────────────────────────────────────────────────────────
    // StatementService
    // ─────────────────────────────────────────────────────────
    public class StatementService
    {
        private readonly DatabaseContext _db;
        public StatementService(DatabaseContext db) => _db = db;

        public async Task<List<Announcement>> GetAnnouncementsAsync()
        {
            var rows = await _db.ExecuteQueryAsync(
                "SELECT * FROM Announcements WHERE IsActive = 1 AND (ExpiresAt IS NULL OR ExpiresAt > GETDATE()) ORDER BY CreatedAt DESC");
            return rows.Select(r => new Announcement
            {
                AnnouncementId = Convert.ToInt32(r["AnnouncementId"]),
                Title          = r["Title"]?.ToString() ?? "",
                Content        = r["Content"]?.ToString() ?? "",
                CreatedAt      = Convert.ToDateTime(r["CreatedAt"]),
                ExpiresAt      = r["ExpiresAt"] == null ? null : Convert.ToDateTime(r["ExpiresAt"]),
                IsActive       = Convert.ToBoolean(r["IsActive"])
            }).ToList();
        }
    }
}
