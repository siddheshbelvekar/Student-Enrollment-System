-- ============================================================
-- Student Enrollment System - Full Database Schema
-- Microsoft SQL Server
-- ============================================================

USE master;
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = 'StudentEnrollmentDB')
    DROP DATABASE StudentEnrollmentDB;
GO

CREATE DATABASE StudentEnrollmentDB;
GO

USE StudentEnrollmentDB;
GO

-- ============================================================
-- TABLE: Roles
-- ============================================================
CREATE TABLE Roles (
    RoleId   INT PRIMARY KEY IDENTITY(1,1),
    RoleName NVARCHAR(50) NOT NULL UNIQUE
);

-- ============================================================
-- TABLE: Students (also used for Admin users)
-- ============================================================
CREATE TABLE Students (
    StudentId       INT PRIMARY KEY IDENTITY(1,1),
    StudentNumber   NVARCHAR(20) NOT NULL UNIQUE,
    FirstName       NVARCHAR(100) NOT NULL,
    LastName        NVARCHAR(100) NOT NULL,
    Email           NVARCHAR(200) NOT NULL UNIQUE,
    PasswordHash    NVARCHAR(500) NOT NULL,
    PhoneNumber     NVARCHAR(20),
    DateOfBirth     DATE,
    Address         NVARCHAR(500),
    Program         NVARCHAR(200),
    YearLevel       INT DEFAULT 1,
    RoleId          INT NOT NULL DEFAULT 2,
    ProfilePicture  NVARCHAR(500),
    IsActive        BIT DEFAULT 1,
    CreatedAt       DATETIME2 DEFAULT GETDATE(),
    UpdatedAt       DATETIME2 DEFAULT GETDATE(),
    CONSTRAINT FK_Students_Roles FOREIGN KEY (RoleId) REFERENCES Roles(RoleId)
);

-- ============================================================
-- TABLE: Courses
-- ============================================================
CREATE TABLE Courses (
    CourseId        INT PRIMARY KEY IDENTITY(1,1),
    CourseCode      NVARCHAR(20) NOT NULL UNIQUE,
    CourseName      NVARCHAR(200) NOT NULL,
    Description     NVARCHAR(1000),
    Credits         INT NOT NULL DEFAULT 3,
    MaxCapacity     INT NOT NULL DEFAULT 40,
    CurrentEnrolled INT NOT NULL DEFAULT 0,
    Instructor      NVARCHAR(200),
    Department      NVARCHAR(200),
    Semester        NVARCHAR(50),
    AcademicYear    NVARCHAR(20),
    FeeAmount       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    IsActive        BIT DEFAULT 1,
    CreatedAt       DATETIME2 DEFAULT GETDATE()
);

-- ============================================================
-- TABLE: CourseTimetable
-- ============================================================
CREATE TABLE CourseTimetable (
    TimetableId     INT PRIMARY KEY IDENTITY(1,1),
    CourseId        INT NOT NULL,
    DayOfWeek       NVARCHAR(20) NOT NULL,  -- Monday, Tuesday, etc.
    StartTime       TIME NOT NULL,
    EndTime         TIME NOT NULL,
    Room            NVARCHAR(50),
    Building        NVARCHAR(100),
    CONSTRAINT FK_CourseTimetable_Courses FOREIGN KEY (CourseId) REFERENCES Courses(CourseId) ON DELETE CASCADE
);

-- ============================================================
-- TABLE: Enrollments
-- ============================================================
CREATE TABLE Enrollments (
    EnrollmentId    INT PRIMARY KEY IDENTITY(1,1),
    StudentId       INT NOT NULL,
    CourseId        INT NOT NULL,
    EnrollmentDate  DATETIME2 DEFAULT GETDATE(),
    Status          NVARCHAR(20) DEFAULT 'Active',  -- Active, Dropped, Completed
    Grade           NVARCHAR(5),
    Semester        NVARCHAR(50),
    AcademicYear    NVARCHAR(20),
    CONSTRAINT FK_Enrollments_Students FOREIGN KEY (StudentId) REFERENCES Students(StudentId),
    CONSTRAINT FK_Enrollments_Courses  FOREIGN KEY (CourseId)  REFERENCES Courses(CourseId),
    CONSTRAINT UQ_Enrollment UNIQUE (StudentId, CourseId, Semester, AcademicYear)
);

-- ============================================================
-- TABLE: AddDropHistory
-- ============================================================
CREATE TABLE AddDropHistory (
    HistoryId       INT PRIMARY KEY IDENTITY(1,1),
    StudentId       INT NOT NULL,
    CourseId        INT NOT NULL,
    ActionType      NVARCHAR(10) NOT NULL,  -- Add, Drop
    ActionDate      DATETIME2 DEFAULT GETDATE(),
    Reason          NVARCHAR(500),
    ProcessedBy     NVARCHAR(200),
    Semester        NVARCHAR(50),
    AcademicYear    NVARCHAR(20),
    CONSTRAINT FK_AddDropHistory_Students FOREIGN KEY (StudentId) REFERENCES Students(StudentId),
    CONSTRAINT FK_AddDropHistory_Courses  FOREIGN KEY (CourseId)  REFERENCES Courses(CourseId)
);

-- ============================================================
-- TABLE: Enquiries (Contact Us)
-- ============================================================
CREATE TABLE Enquiries (
    EnquiryId       INT PRIMARY KEY IDENTITY(1,1),
    StudentId       INT,
    FullName        NVARCHAR(200) NOT NULL,
    Email           NVARCHAR(200) NOT NULL,
    Subject         NVARCHAR(300) NOT NULL,
    Message         NVARCHAR(2000) NOT NULL,
    Status          NVARCHAR(20) DEFAULT 'Pending',  -- Pending, Replied, Closed
    AdminReply      NVARCHAR(2000),
    SubmittedAt     DATETIME2 DEFAULT GETDATE(),
    RepliedAt       DATETIME2,
    CONSTRAINT FK_Enquiries_Students FOREIGN KEY (StudentId) REFERENCES Students(StudentId)
);

-- ============================================================
-- TABLE: Feedback (Student Evaluation of Teaching)
-- ============================================================
CREATE TABLE Feedback (
    FeedbackId          INT PRIMARY KEY IDENTITY(1,1),
    StudentId           INT NOT NULL,
    CourseId            INT NOT NULL,
    TeachingRating      INT NOT NULL CHECK (TeachingRating BETWEEN 1 AND 5),
    ContentRating       INT NOT NULL CHECK (ContentRating BETWEEN 1 AND 5),
    MaterialRating      INT NOT NULL CHECK (MaterialRating BETWEEN 1 AND 5),
    OverallRating       INT NOT NULL CHECK (OverallRating BETWEEN 1 AND 5),
    Comments            NVARCHAR(2000),
    IsAnonymous         BIT DEFAULT 0,
    SubmittedAt         DATETIME2 DEFAULT GETDATE(),
    Semester            NVARCHAR(50),
    AcademicYear        NVARCHAR(20),
    CONSTRAINT FK_Feedback_Students FOREIGN KEY (StudentId) REFERENCES Students(StudentId),
    CONSTRAINT FK_Feedback_Courses  FOREIGN KEY (CourseId)  REFERENCES Courses(CourseId),
    CONSTRAINT UQ_Feedback UNIQUE (StudentId, CourseId, Semester, AcademicYear)
);

-- ============================================================
-- TABLE: Payments
-- ============================================================
CREATE TABLE Payments (
    PaymentId           INT PRIMARY KEY IDENTITY(1,1),
    StudentId           INT NOT NULL,
    PaymentReference    NVARCHAR(50) NOT NULL UNIQUE,
    Amount              DECIMAL(10,2) NOT NULL,
    PaymentMethod       NVARCHAR(50),  -- CreditCard, DebitCard, BankTransfer, Online
    CardLastFour        NVARCHAR(4),
    PaymentDate         DATETIME2 DEFAULT GETDATE(),
    Status              NVARCHAR(20) DEFAULT 'Pending',  -- Pending, Completed, Failed, Refunded
    Description         NVARCHAR(500),
    Semester            NVARCHAR(50),
    AcademicYear        NVARCHAR(20),
    CONSTRAINT FK_Payments_Students FOREIGN KEY (StudentId) REFERENCES Students(StudentId)
);

-- ============================================================
-- TABLE: Invoices
-- ============================================================
CREATE TABLE Invoices (
    InvoiceId           INT PRIMARY KEY IDENTITY(1,1),
    InvoiceNumber       NVARCHAR(50) NOT NULL UNIQUE,
    StudentId           INT NOT NULL,
    PaymentId           INT,
    SubTotal            DECIMAL(10,2) NOT NULL,
    Discount            DECIMAL(10,2) DEFAULT 0,
    Tax                 DECIMAL(10,2) DEFAULT 0,
    TotalAmount         DECIMAL(10,2) NOT NULL,
    Status              NVARCHAR(20) DEFAULT 'Unpaid',  -- Unpaid, Paid, Partial, Voided
    DueDate             DATE,
    IssuedDate          DATETIME2 DEFAULT GETDATE(),
    PaidDate            DATETIME2,
    Notes               NVARCHAR(500),
    Semester            NVARCHAR(50),
    AcademicYear        NVARCHAR(20),
    CONSTRAINT FK_Invoices_Students FOREIGN KEY (StudentId) REFERENCES Students(StudentId),
    CONSTRAINT FK_Invoices_Payments FOREIGN KEY (PaymentId) REFERENCES Payments(PaymentId)
);

-- ============================================================
-- TABLE: InvoiceItems
-- ============================================================
CREATE TABLE InvoiceItems (
    ItemId      INT PRIMARY KEY IDENTITY(1,1),
    InvoiceId   INT NOT NULL,
    CourseId    INT,
    Description NVARCHAR(300) NOT NULL,
    Quantity    INT DEFAULT 1,
    UnitPrice   DECIMAL(10,2) NOT NULL,
    TotalPrice  DECIMAL(10,2) NOT NULL,
    CONSTRAINT FK_InvoiceItems_Invoices FOREIGN KEY (InvoiceId) REFERENCES Invoices(InvoiceId) ON DELETE CASCADE,
    CONSTRAINT FK_InvoiceItems_Courses  FOREIGN KEY (CourseId)  REFERENCES Courses(CourseId)
);

-- ============================================================
-- TABLE: BankDetails
-- ============================================================
CREATE TABLE BankDetails (
    BankDetailId    INT PRIMARY KEY IDENTITY(1,1),
    StudentId       INT NOT NULL UNIQUE,
    BankName        NVARCHAR(200),
    AccountHolderName NVARCHAR(200),
    AccountNumber   NVARCHAR(50),
    RoutingNumber   NVARCHAR(50),
    AccountType     NVARCHAR(20),  -- Savings, Checking
    UpdatedAt       DATETIME2 DEFAULT GETDATE(),
    CONSTRAINT FK_BankDetails_Students FOREIGN KEY (StudentId) REFERENCES Students(StudentId)
);

-- ============================================================
-- TABLE: Announcements
-- ============================================================
CREATE TABLE Announcements (
    AnnouncementId  INT PRIMARY KEY IDENTITY(1,1),
    Title           NVARCHAR(300) NOT NULL,
    Content         NVARCHAR(2000) NOT NULL,
    CreatedBy       INT,
    CreatedAt       DATETIME2 DEFAULT GETDATE(),
    ExpiresAt       DATETIME2,
    IsActive        BIT DEFAULT 1,
    CONSTRAINT FK_Announcements_Students FOREIGN KEY (CreatedBy) REFERENCES Students(StudentId)
);

-- ============================================================
-- SEED DATA
-- ============================================================

-- Roles
INSERT INTO Roles (RoleName) VALUES ('Admin'), ('Student');

-- Admin User (Password: Admin@123)
-- BCrypt hash for "Admin@123"
INSERT INTO Students (StudentNumber, FirstName, LastName, Email, PasswordHash, PhoneNumber, Program, YearLevel, RoleId)
VALUES ('ADMIN001', 'System', 'Administrator', 'admin@university.edu',
        '$2a$11$b.fAcu8Ng8uZkWCTZE1EO.UkYSLaSV/.sXo2RVfwBWmVtRAWTLMry',
        '+60123456789', 'Administration', 1, 1);

-- Students (Password for all: Student@123)
INSERT INTO Students (StudentNumber, FirstName, LastName, Email, PasswordHash, PhoneNumber, DateOfBirth, Address, Program, YearLevel, RoleId)
VALUES
('STU2024001', 'Ahmad', 'Razali', 'ahmad.razali@student.edu',
 '$2a$11$JK3D0ygYc20fyuqRK1cHwupvikD4fZOiMvhjzkAqPpCcCL8z7VxP2',
 '+60112345678', '2002-05-15', '123 Jalan Merdeka, Kuala Lumpur', 'Computer Science', 2, 2),

('STU2024002', 'Siti', 'Nurhaliza', 'siti.nurhaliza@student.edu',
 '$2a$11$JK3D0ygYc20fyuqRK1cHwupvikD4fZOiMvhjzkAqPpCcCL8z7VxP2',
 '+60187654321', '2003-08-22', '456 Jalan Ampang, Kuala Lumpur', 'Business Administration', 1, 2),

('STU2024003', 'Rajesh', 'Kumar', 'rajesh.kumar@student.edu',
 '$2a$11$JK3D0ygYc20fyuqRK1cHwupvikD4fZOiMvhjzkAqPpCcCL8z7VxP2',
 '+60198765432', '2001-12-10', '789 Jalan Cheras, Kuala Lumpur', 'Engineering', 3, 2);

-- Courses
INSERT INTO Courses (CourseCode, CourseName, Description, Credits, MaxCapacity, Instructor, Department, Semester, AcademicYear, FeeAmount)
VALUES
('CS101', 'Introduction to Programming', 'Fundamentals of programming using Python', 3, 40, 'Dr. Lee Wei Ming', 'Computer Science', 'Semester 1', '2024/2025', 450.00),
('CS201', 'Data Structures & Algorithms', 'Advanced data structures and algorithm analysis', 3, 35, 'Prof. Sarah Johnson', 'Computer Science', 'Semester 1', '2024/2025', 500.00),
('CS301', 'Database Management Systems', 'Relational databases, SQL, and normalization', 3, 30, 'Dr. Tan Ah Kow', 'Computer Science', 'Semester 1', '2024/2025', 500.00),
('CS401', 'Software Engineering', 'Software development lifecycle and methodologies', 3, 30, 'Dr. Maria Santos', 'Computer Science', 'Semester 1', '2024/2025', 550.00),
('MATH101', 'Calculus I', 'Differential and integral calculus', 4, 45, 'Prof. Ahmad Fauzi', 'Mathematics', 'Semester 1', '2024/2025', 400.00),
('MATH201', 'Linear Algebra', 'Vectors, matrices, and linear transformations', 3, 40, 'Dr. Priya Sharma', 'Mathematics', 'Semester 1', '2024/2025', 400.00),
('BUS101', 'Business Management', 'Principles of management and organizational behavior', 3, 50, 'Prof. David Lim', 'Business', 'Semester 1', '2024/2025', 380.00),
('BUS201', 'Accounting Fundamentals', 'Basic accounting principles and financial statements', 3, 45, 'Dr. Janet Wong', 'Business', 'Semester 1', '2024/2025', 380.00),
('ENG101', 'Engineering Mathematics', 'Mathematical methods for engineers', 4, 40, 'Dr. Kamal Hassan', 'Engineering', 'Semester 1', '2024/2025', 420.00),
('ENG201', 'Thermodynamics', 'Heat, work, and energy in engineering systems', 3, 35, 'Prof. Richard Ng', 'Engineering', 'Semester 1', '2024/2025', 480.00);

-- Update enrollment counts
UPDATE Courses SET CurrentEnrolled = 15 WHERE CourseCode = 'CS101';
UPDATE Courses SET CurrentEnrolled = 20 WHERE CourseCode = 'CS201';
UPDATE Courses SET CurrentEnrolled = 10 WHERE CourseCode = 'CS301';

-- Timetables
INSERT INTO CourseTimetable (CourseId, DayOfWeek, StartTime, EndTime, Room, Building)
VALUES
(1, 'Monday',    '08:00', '10:00', 'Lab 1',   'Science Block'),
(1, 'Wednesday', '10:00', '12:00', 'Lab 1',   'Science Block'),
(2, 'Tuesday',   '10:00', '12:00', 'Room 201','Main Block'),
(2, 'Thursday',  '14:00', '16:00', 'Room 201','Main Block'),
(3, 'Monday',    '14:00', '16:00', 'Lab 2',   'Science Block'),
(3, 'Friday',    '08:00', '10:00', 'Lab 2',   'Science Block'),
(4, 'Tuesday',   '08:00', '10:00', 'Room 301','Main Block'),
(4, 'Thursday',  '10:00', '12:00', 'Room 301','Main Block'),
(5, 'Monday',    '10:00', '12:00', 'Room 101','Annex Block'),
(5, 'Wednesday', '14:00', '16:00', 'Room 101','Annex Block'),
(6, 'Tuesday',   '14:00', '16:00', 'Room 102','Annex Block'),
(6, 'Friday',    '10:00', '12:00', 'Room 102','Annex Block'),
(7, 'Wednesday', '08:00', '10:00', 'Room 401','Business Block'),
(7, 'Friday',    '14:00', '16:00', 'Room 401','Business Block'),
(8, 'Monday',    '08:00', '10:00', 'Room 402','Business Block'),  -- Conflicts with CS101!
(8, 'Thursday',  '08:00', '10:00', 'Room 402','Business Block'),
(9, 'Tuesday',   '08:00', '10:00', 'ELab 1',  'Engineering Block'),
(9, 'Thursday',  '14:00', '16:00', 'ELab 1',  'Engineering Block'),
(10,'Wednesday', '10:00', '12:00', 'ELab 2',  'Engineering Block'),
(10,'Friday',    '12:00', '14:00', 'ELab 2',  'Engineering Block');

-- Sample Enrollments for STU2024001
INSERT INTO Enrollments (StudentId, CourseId, Status, Semester, AcademicYear)
VALUES
(2, 1, 'Active', 'Semester 1', '2024/2025'),
(2, 2, 'Active', 'Semester 1', '2024/2025'),
(2, 5, 'Active', 'Semester 1', '2024/2025');

-- Sample Enrollments for STU2024002
INSERT INTO Enrollments (StudentId, CourseId, Status, Semester, AcademicYear)
VALUES
(3, 7, 'Active', 'Semester 1', '2024/2025'),
(3, 8, 'Active', 'Semester 1', '2024/2025');

-- Add/Drop History
INSERT INTO AddDropHistory (StudentId, CourseId, ActionType, Reason, Semester, AcademicYear)
VALUES
(2, 3, 'Add', 'Required course for major', 'Semester 1', '2024/2025'),
(2, 3, 'Drop', 'Schedule conflict with part-time work', 'Semester 1', '2024/2025'),
(3, 9, 'Add', 'Elective course', 'Semester 1', '2024/2025');

-- Sample Payment
INSERT INTO Payments (StudentId, PaymentReference, Amount, PaymentMethod, CardLastFour, Status, Description, Semester, AcademicYear)
VALUES
(2, 'PAY-2024-000001', 1350.00, 'CreditCard', '4242', 'Completed', 'Semester 1 Tuition Fee', 'Semester 1', '2024/2025'),
(3, 'PAY-2024-000002', 760.00,  'Online',      NULL,   'Completed', 'Semester 1 Tuition Fee', 'Semester 1', '2024/2025');

-- Sample Invoice
INSERT INTO Invoices (InvoiceNumber, StudentId, PaymentId, SubTotal, Discount, Tax, TotalAmount, Status, DueDate, PaidDate, Semester, AcademicYear)
VALUES
('INV-2024-000001', 2, 1, 1350.00, 0, 0, 1350.00, 'Paid', '2024-09-30', GETDATE(), 'Semester 1', '2024/2025'),
('INV-2024-000002', 3, 2, 760.00,  0, 0, 760.00,  'Paid', '2024-09-30', GETDATE(), 'Semester 1', '2024/2025');

INSERT INTO InvoiceItems (InvoiceId, CourseId, Description, Quantity, UnitPrice, TotalPrice)
VALUES
(1, 1, 'CS101 - Introduction to Programming', 1, 450.00, 450.00),
(1, 2, 'CS201 - Data Structures & Algorithms', 1, 500.00, 500.00),
(1, 5, 'MATH101 - Calculus I', 1, 400.00, 400.00),
(2, 7, 'BUS101 - Business Management', 1, 380.00, 380.00),
(2, 8, 'BUS201 - Accounting Fundamentals', 1, 380.00, 380.00);

-- Enquiries
INSERT INTO Enquiries (StudentId, FullName, Email, Subject, Message, Status)
VALUES
(2, 'Ahmad Razali', 'ahmad.razali@student.edu', 'Course Registration Issue', 'I am unable to register for CS301. The system shows an error.', 'Pending'),
(NULL, 'John Doe', 'john.doe@email.com', 'Admission Inquiry', 'I would like to know about the Computer Science program requirements.', 'Replied');

-- Feedback
INSERT INTO Feedback (StudentId, CourseId, TeachingRating, ContentRating, MaterialRating, OverallRating, Comments, IsAnonymous, Semester, AcademicYear)
VALUES
(2, 1, 5, 4, 4, 5, 'Excellent teaching style. Very clear explanations.', 0, 'Semester 1', '2024/2025');

-- BankDetails
INSERT INTO BankDetails (StudentId, BankName, AccountHolderName, AccountNumber, RoutingNumber, AccountType)
VALUES
(2, 'Maybank', 'Ahmad Razali', '1234-5678-9012', 'MBB001', 'Savings');

-- Announcements
INSERT INTO Announcements (Title, Content, CreatedBy, ExpiresAt)
VALUES
('Semester 1 Registration Open', 'Online registration for Semester 1 2024/2025 is now open. Please complete your enrollment by September 15.', 1, '2025-01-31'),
('Payment Deadline Reminder', 'Please settle your tuition fees before September 30 to avoid late payment penalties.', 1, '2025-01-31'),
('System Maintenance Notice', 'The student portal will be under maintenance on Sunday 2:00 AM - 6:00 AM.', 1, '2025-01-31');

GO

PRINT 'Database setup completed successfully!';
